setwd("C:\\Users\\it24102519\\Desktop\\IT24102519")


data <- read.table("Data - Lab 8.txt", header = TRUE)
attach(data)


popmn <- mean(Nicotine)
popvar <- var(Nicotine)  # Calculate population variance


samples <- list()
n <- c()


for(i in 1:30) {
  s <- sample(Nicotine, 5, replace = TRUE)
  samples[[i]] <- s
  n <- c(n, paste('S', i))  # Sample names
}


samples_matrix <- do.call(cbind, samples)


colnames(samples_matrix) <- n


s.means <- apply(samples_matrix, 2, mean)
s.vars <- apply(samples_matrix, 2, var)


samplemean <- mean(s.means)  # Mean of sample means
samplevars <- var(s.means)  # Variance of sample means


popmn
samplemean

truevar=popvar/5
samplevars


