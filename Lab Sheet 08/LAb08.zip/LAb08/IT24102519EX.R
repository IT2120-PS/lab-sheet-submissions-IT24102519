# Set working directory to your folder (update with your actual path)
setwd("C:\\Users\\it24102519\\Desktop\\IT24102519")

# Read the data (replace the file name with the correct one)
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

# Assuming the data has a column named 'Weight' which contains the weights of laptop bags
# Calculate Population Mean and Population Standard Deviation
pop_mean <- mean(data$Weight)
pop_sd <- sd(data$Weight)

# Print results for population mean and standard deviation
pop_mean
pop_sd

# Set seed for reproducibility
set.seed(123)

# Create a matrix with 6 rows (sample size), 25 columns (samples)
samples <- matrix(nrow = 6, ncol = 25)

# Fill matrix with random samples
for (i in 1:25) {
  samples[, i] <- sample(data$Weight, 6, replace = TRUE)  # Fix here: use data$Weight
}

# Sample means and standard deviations
sample_means <- apply(samples, 2, mean)
sample_sds <- apply(samples, 2, sd)

# Create a table of results
sample_stats <- data.frame(
  Sample = 1:25,
  Mean = round(sample_means, 4),
  SD = round(sample_sds, 4)
)

# Print sample statistics
print(sample_stats)

# Calculate the mean and standard deviation of the sample means
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

# Print the mean and standard deviation of the sample means
mean_of_sample_means
sd_of_sample_means
