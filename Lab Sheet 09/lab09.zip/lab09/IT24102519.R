setwd("C:\\Users\\User\\Documents\\SLIIT\\Year 2\\sem 1\\PS\\lab\\lab09")
getwd()

#Qusteing 1
x<-c(3,7,11,0,7,0,4,5,6,2)
t.test(x,mu=3)

#Qustion 2
#part1
weight<-c(17.6, 20.6, 22.2, 15.3, 20.9, 21.0, 18.9, 18.9, 18.9, 18.2)
t.test(wight,mu=25,alternation="less")

#part2
rea<-t.test(weight,mu=25,altenative="less")

rea$statistic

rea$p.value

rea$conf.int

#Question 3
#part 1
y<-rnorm(30,mean=9.8,sd=0.05)

t.test(y,mu=10,alternative = "greater")

#exercise

set.seed(42)   # for reproducibility
sample <- rnorm(25, mean = 45, sd = 2)
sample

t.test(sample, mu = 46, alternative = "less")
